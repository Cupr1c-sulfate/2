#import <UIKit/UIKit.h>
#import <NodeMobile/NodeMobile.h>
#include <vector>
#include <string>
#include <unistd.h>

@interface ProbeViewController : UIViewController
@property(nonatomic,strong) UITextView *output;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) NSString *reportPath;
@end
@implementation ProbeViewController
- (void)viewDidLoad {
  [super viewDidLoad];
  self.title = @"DSH 本机验证";
  self.view.backgroundColor = UIColor.systemBackgroundColor;
  self.output = [[UITextView alloc] initWithFrame:CGRectZero];
  self.output.editable = NO;
  self.output.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular];
  self.output.translatesAutoresizingMaskIntoConstraints = NO;
  self.output.text = @"正在启动 iPhone 本机 Node.js…\n这是依赖与启动诊断，不是完整 DSH Go。\n请保持前台，约一分钟后完成。";
  [self.view addSubview:self.output];
  [NSLayoutConstraint activateConstraints:@[
    [self.output.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
    [self.output.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
    [self.output.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:12],
    [self.output.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-12]]];
  self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"分享报告" style:UIBarButtonItemStylePlain target:self action:@selector(shareReport)];
  NSString *support = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES).firstObject;
  NSString *root = [support stringByAppendingPathComponent:@"DSHProbe"];
  NSError *error=nil;
  if(![[NSFileManager defaultManager] createDirectoryAtPath:root withIntermediateDirectories:YES attributes:nil error:&error]) {
    self.output.text=error.localizedDescription;return;
  }
  self.reportPath=[root stringByAppendingPathComponent:@"report.json"];
  [[NSFileManager defaultManager] removeItemAtPath:self.reportPath error:nil];
  NSString *script=[[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"nodejs-project/probe.cjs"];
  if(![[NSFileManager defaultManager] fileExistsAtPath:script]) {self.output.text=@"构建缺少 probe.cjs";return;}
  self.timer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(refreshReport) userInfo:nil repeats:YES];
  // Node may be started only once during this application process.
  NSThread *thread=[[NSThread alloc] initWithBlock:^{
    @autoreleasepool {
      setenv("DSH_PROBE_ROOT",root.UTF8String,1);
      chdir(root.UTF8String);
      NSArray<NSString *> *arguments=@[@"node",@"--max-old-space-size=384",script];
      size_t bytes=0;
      for(NSString *arg in arguments) bytes+=strlen(arg.UTF8String)+1;
      std::vector<char> storage(bytes);
      std::vector<char *> argv(arguments.count+1,nullptr);
      char *cursor=storage.data();
      for(NSUInteger i=0;i<arguments.count;i++) {
        const char *arg=arguments[i].UTF8String;
        size_t length=strlen(arg)+1;
        memcpy(cursor,arg,length);argv[i]=cursor;cursor+=length;
      }
      int result=node_start((int)arguments.count,argv.data());
      dispatch_async(dispatch_get_main_queue(),^{
        [self refreshReport];
        if(![[NSFileManager defaultManager] fileExistsAtPath:self.reportPath])
          self.output.text=[NSString stringWithFormat:@"Node.js 返回 %d，但未生成报告。需要查看设备崩溃日志。",result];
      });
    }
  }];
  thread.stackSize=4*1024*1024;
  [thread start];
}
- (void)refreshReport {
  NSString *text=[NSString stringWithContentsOfFile:self.reportPath encoding:NSUTF8StringEncoding error:nil];
  if(text.length) self.output.text=text;
}
- (void)shareReport {
  if(![[NSFileManager defaultManager] fileExistsAtPath:self.reportPath])return;
  UIActivityViewController *share=[[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:self.reportPath]] applicationActivities:nil];
  share.popoverPresentationController.barButtonItem=self.navigationItem.rightBarButtonItem;
  [self presentViewController:share animated:YES completion:nil];
}
@end
@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation AppDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)options {
  self.window=[[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
  self.window.rootViewController=[[UINavigationController alloc] initWithRootViewController:[ProbeViewController new]];
  [self.window makeKeyAndVisible];return YES;
}
@end
int main(int argc,char **argv) {
  @autoreleasepool {return UIApplicationMain(argc,argv,nil,NSStringFromClass([AppDelegate class]));}
}
