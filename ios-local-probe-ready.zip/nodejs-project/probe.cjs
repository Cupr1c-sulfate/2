'use strict';
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { Worker } = require('node:worker_threads');
const { createRequire } = require('node:module');

function redact(value) {
  return String(value).replace(/(Bearer\s+)[^\s"']+/gi, '$1[redacted]')
    .replace(/((?:api[_-]?key|access[_-]?token|token|password|secret)["']?\s*[:=]\s*["']?)[^\s"'&,}]+/gi, '$1[redacted]');
}
function writeReport(file, report) {
  fs.writeFileSync(file + '.tmp', JSON.stringify(report, null, 2));
  fs.renameSync(file + '.tmp', file);
}
function runCLI(entry, args, env, timeoutMs, onEvent) {
  return new Promise((resolve) => {
    let ended = false, timedOut = false;
    const worker = new Worker(entry, { argv: args, env, stdout: true, stderr: true,
      execArgv: ['--require', path.join(__dirname, 'loopback-only.cjs')] });
    const finish = (result) => { if (!ended) { ended = true; clearTimeout(timer); resolve(result); } };
    worker.stdout.on('data', chunk => onEvent({kind:'stdout', text:redact(chunk.toString()).slice(0,8000)}));
    worker.stderr.on('data', chunk => onEvent({kind:'stderr', text:redact(chunk.toString()).slice(0,8000)}));
    worker.on('message', data => onEvent(data));
    worker.on('error', error => finish({status:'error', error:redact(error.stack)}));
    worker.on('exit', code => finish({status:timedOut?'observation_window_ended':'exited', code}));
    const timer = setTimeout(async () => { timedOut=true; const code = await worker.terminate(); finish({status:'observation_window_ended', code}); }, timeoutMs);
  });
}
async function probe(options = {}) {
  const root = options.root || process.env.DSH_PROBE_ROOT;
  if (!root) throw new Error('DSH_PROBE_ROOT is required');
  fs.mkdirSync(root, {recursive:true});
  const file = path.join(root, 'report.json');
  const report = {startedAt:new Date().toISOString(), platform:process.platform,
    node:process.versions.node, mobile:process.versions.mobile || null,
    mode:'diagnostic-only', dshVersion:'0.2.1-rc.4', checks:[], events:[],
    fullDSHVerified:false, modelConversationTested:false};
  const save = () => writeReport(file, report);
  const check = async (name, fn) => { try { report.checks.push({name,status:'passed',detail:await fn()}); }
    catch(e) {report.checks.push({name,status:'failed',error:redact(e.stack)});} save(); };
  save();
  await check('Node >= 24.9', () => {const [a,b]=process.versions.node.split('.').map(Number); if(a<24 || (a===24&&b<9))throw Error('Node 24.9+ required'); return process.version;});
  await check('Sandbox file read/write', () => { const f=path.join(root,'probe.txt');fs.writeFileSync(f,'iPhone local runtime probe');const text=fs.readFileSync(f,'utf8');fs.unlinkSync(f);return text;});
  await check('Built-in SQLite', () => {const {DatabaseSync}=require('node:sqlite');const db=new DatabaseSync(':memory:');try {return db.prepare('select 1 as value').get();}finally{db.close();}});
  await check('Loopback HTTP + fetch', async () => {
    const server=http.createServer((req,res)=>res.end('local-ok'));
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
    try {const response=await fetch('http://127.0.0.1:'+server.address().port,{signal:AbortSignal.timeout(5000)});const body=await response.text();if(body!=='local-ok')throw Error('Unexpected loopback response');return body;}
    finally {await new Promise(resolve=>server.close(resolve));}
  });
  let entry;
  await check('Real DSH package present', () => {
    const folder=path.join(__dirname,'node_modules','@deepseek-ai','dsh');
    const pkg=JSON.parse(fs.readFileSync(path.join(folder,'package.json'),'utf8'));
    if(pkg.version!==report.dshVersion)throw Error('DSH version differs from pin');
    entry=path.join(folder,typeof pkg.bin==='string'?pkg.bin:pkg.bin.dsh);
    fs.accessSync(entry);return pkg.version;
  });
  if(entry) {
    const req=createRequire(entry);
    for(const name of ['koffi','node-pty','sharp']) await check('Native dependency: '+name,()=>{req(name);return 'loaded';});
    const env={...process.env,DSH_HOME:path.join(root,'dsh-home'),DSH_PROBE_ROOT:root};
    const onEvent = event => {report.events.push(event); if(report.events.length>100)report.events.shift();save();};
    report.versionCommand=await runCLI(entry,['--version'],env,20000,onEvent);save();
    // A module import, a worker exit code, or an HTTP listener is NOT proof of a working agent.
    report.engineAttempt={status:'running',command:'dsh web',durationSeconds:45};save();
    report.engineAttempt=await runCLI(entry,['web'],env,45000,onEvent);save();
  }
  report.finishedAt=new Date().toISOString();save();return report;
}
module.exports={probe,redact,runCLI};
if(require.main===module) probe().catch(e=>{
  const root=process.env.DSH_PROBE_ROOT;
  if(root) writeReport(path.join(root,'report.json'),{fatal:redact(e.stack),fullDSHVerified:false});
  console.error(redact(e.stack));process.exitCode=1;
});
