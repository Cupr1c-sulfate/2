'use strict';
// Probe-only change: do not expose the unconfigured engine to the local network.
const net=require('node:net');
const {parentPort}=require('node:worker_threads');
const original=net.Server.prototype.listen;
net.Server.prototype.listen=function(...args) {
  const callback=typeof args.at(-1)==='function'?args.pop():undefined;
  let port;
  if(typeof args[0]==='object' && args[0]!==null) {
    if(args[0].path || args[0].fd || args[0].handle)throw Error('Probe allows TCP loopback only');
    port=args[0].port;
  } else if(typeof args[0]==='number' || /^\d+$/.test(String(args[0]))) port=Number(args[0]);
  else throw Error('Probe allows TCP loopback only');
  this.once('listening',()=>parentPort?.postMessage({kind:'listener',address:this.address(),note:'Listener observed; full engine and chat remain unverified'}));
  return callback?original.call(this,{port,host:'127.0.0.1'},callback):original.call(this,{port,host:'127.0.0.1'});
};
