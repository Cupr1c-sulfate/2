#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p Vendor build
archive=build/nodejs-mobile-ios-24.22.1-0.zip
curl --fail --location --retry 3 'https://github.com/fogtape/nodejs-mobile/releases/download/v24.22.1-0/nodejs-mobile-ios-24.22.1-0.zip' -o "$archive"
printf '%s  %s\n' '3fa1b8fb0720768b01c2e0dae3a17e788476e8c1613a1d9a54e206793b45326e' "$archive" | shasum -a 256 -c -
ditto -x -k "$archive" Vendor
test -f Vendor/NodeMobile.xcframework/Info.plist
npm ci --prefix nodejs-project --ignore-scripts --omit=dev --omit=optional --no-audit --no-fund
python3 scripts/native_inventory.py
