"""Exclude desktop native binaries from the iOS bundle; record what needs porting."""
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1] / 'nodejs-project'
removed = []
for pattern in ('*.node', '*.so', '*.dylib', '*.dll', '*.exe'):
    for file in (root / 'node_modules').rglob(pattern):
        if file.is_file() or file.is_symlink():
            removed.append(str(file.relative_to(root)))
            file.unlink()
(root / 'native-inventory.json').write_text(json.dumps({
    'note': 'Desktop binaries are not iOS builds. Native module failures are expected until ported.',
    'excluded': sorted(removed),
}, indent=2))
