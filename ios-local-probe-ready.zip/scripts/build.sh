#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
xcodegen generate
xcodebuild -project DSHLocalProbe.xcodeproj -scheme DSHLocalProbe -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
mkdir -p build/Package/Payload
ditto build/DerivedData/Build/Products/Release-iphoneos/DSHLocalProbe.app build/Package/Payload/DSHLocalProbe.app
cd build/Package
zip -qry ../DSHLocalProbe-unsigned.ipa Payload
