'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {redact,runCLI,probe}=require('../nodejs-project/probe.cjs');
test('report redacts token and authorization values',()=>{
  const result=redact('Bearer abc123 token=xyz password: p123 api_key="k456"');
  for(const value of ['abc123','xyz','p123','k456'])assert.ok(!result.includes(value));
});
test('worker exit is recorded, never promoted to engine success',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'probe-test-'));
  try {
    const entry=path.join(dir,'worker.cjs');fs.writeFileSync(entry,'process.exit(7)');
    const result=await runCLI(entry,[],{...process.env},2000,()=>{});
    assert.deepEqual(result,{status:'exited',code:7});
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
test('live worker times out and terminates',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'probe-test-'));
  try {
    const entry=path.join(dir,'worker.cjs');fs.writeFileSync(entry,'setInterval(()=>{},100)');
    const result=await runCLI(entry,[],{...process.env},150,()=>{});
    assert.equal(result.status,'observation_window_ended');
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
test('preload forces attempted wildcard listener to loopback',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'probe-test-'));const events=[];
  try {
    const entry=path.join(dir,'worker.cjs');fs.writeFileSync(entry,"const s=require('net').createServer();s.listen(0,'0.0.0.0',()=>s.close());");
    const result=await runCLI(entry,[],{...process.env},2000,event=>events.push(event));
    assert.equal(result.code,0);
    assert.equal(events.find(x=>x.kind==='listener').address.address,'127.0.0.1');
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
test('missing DSH is an explicit failed check; runtime probes cannot mark DSH verified',async()=>{
  if(fs.existsSync(path.join(__dirname,'../nodejs-project/node_modules')))return;
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'probe-test-'));
  try {
    const report=await probe({root:dir});
    assert.equal(report.fullDSHVerified,false);
    assert.equal(report.modelConversationTested,false);
    assert.equal(report.checks.find(x=>x.name==='Real DSH package present').status,'failed');
    assert.equal(report.checks.find(x=>x.name==='Sandbox file read/write').status,'passed');
    assert.equal(report.checks.find(x=>x.name==='Loopback HTTP + fetch').status,'passed');
    assert.ok(fs.existsSync(path.join(dir,'report.json')));
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
